var data = {
  cities: ["Barcelona", "Madrid", "Dublin", "Tokyo"],
};